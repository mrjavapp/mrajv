
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const dotenv = require('dotenv');
const jwt = require('jsonwebtoken');
const User = require('./models/User');
const logAction = require('./utils/logAction');


dotenv.config();

const token = process.env.TELEGRAM_BOT_TOKEN;
const PORT = process.env.PORT || 3000;
const API_URL = `http://localhost:${PORT}/api`;

if (!token) {
  console.error('Telegram Bot Token not found in .env file!');
} else {
  console.log('Telegram Bot is starting...');
  const bot = new TelegramBot(token, { polling: true });

  const userStates = {}; // In-memory store for user states

  const welcomeKeyboard = {
    reply_markup: {
      keyboard: [['ورود به حساب کاربری 🚪']],
      resize_keyboard: true,
      one_time_keyboard: true,
    },
  };
  
  const loggedInKeyboard = {
    reply_markup: {
      keyboard: [['افزودن یادداشت 📝', 'مشاهده یادداشت‌ها 📚'], ['خروج از حساب 👋']],
      resize_keyboard: true,
    },
  };

  const sendWelcomeMessage = (chatId) => {
    bot.sendMessage(
      chatId,
      '🤖 به ربات "زیرو" خوش آمدید!\n\nبرای شروع، لطفاً روی دکمه زیر کلیک کنید تا وارد حساب کاربری خود شوید.',
      welcomeKeyboard
    );
  };
  
  const sendLoggedInMessage = (chatId) => {
    bot.sendMessage(
      chatId,
      'شما با موفقیت وارد شدید! 🎉\n\nاز دکمه‌های زیر برای مدیریت یادداشت‌های خود استفاده کنید.',
      loggedInKeyboard
    );
  };


  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    sendWelcomeMessage(chatId);
  });
  
  bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    // Command handlers
    if (text === 'ورود به حساب کاربری 🚪' || text === '/login') {
        userStates[chatId] = { state: 'AWAITING_PHONE' };
        bot.sendMessage(chatId, '📱 لطفاً شماره تلفن خود را وارد کنید:');
        return;
    }
    
    if (text === 'خروج از حساب 👋' || text === '/logout') {
        const userToken = userStates[chatId]?.token;
        if (userToken) {
            try {
                const decoded = jwt.verify(userToken, process.env.JWT_SECRET);
                if (decoded.id) {
                    await User.findByIdAndUpdate(decoded.id, { telegramChatId: null });
                    await logAction(decoded.id, 'Telegram Bot', 'User Logged Out');
                }
            } catch (err) {
                console.error('Error clearing chatId on logout:', err);
            }
        }
        delete userStates[chatId];
        bot.sendMessage(chatId, 'شما با موفقیت از حساب خود خارج شدید. 👋', welcomeKeyboard);
        return;
    }

    if (text === 'افزودن یادداشت 📝' || text === '/newnote') {
        if (userStates[chatId] && userStates[chatId].token) {
            userStates[chatId].state = 'AWAITING_NOTE_TITLE';
            bot.sendMessage(chatId, '✍️ عنوان یادداشت را وارد کنید:');
        } else {
            bot.sendMessage(chatId, 'ابتدا باید وارد حساب خود شوید.', welcomeKeyboard);
        }
        return;
    }

    if (text === 'مشاهده یادداشت‌ها 📚' || text === '/viewnotes') {
        const userToken = userStates[chatId]?.token;
        if (userToken) {
            try {
                const response = await axios.get(`${API_URL}/notes`, {
                    headers: { Authorization: `Bearer ${userToken}` },
                });
                const notes = response.data;
                if (notes.length === 0) {
                    bot.sendMessage(chatId, 'شما هنوز هیچ یادداشتی ثبت نکرده‌اید. 텅');
                } else {
                    let notesMessage = '📚 یادداشت‌های شما:\n\n';
                    notes.forEach(note => {
                        notesMessage += `*${note.title}*\n${note.content}\n--------------------\n`;
                    });
                    bot.sendMessage(chatId, notesMessage, { parse_mode: 'Markdown' });
                }
                const decoded = jwt.verify(userToken, process.env.JWT_SECRET);
                await logAction(decoded.id, 'Telegram Bot', 'Viewed Notes');

            } catch (error) {
                bot.sendMessage(chatId, 'خطایی در دریافت یادداشت‌ها رخ داد. 😥');
            }
        } else {
            bot.sendMessage(chatId, 'ابتدا باید وارد حساب خود شوید.', welcomeKeyboard);
        }
        return;
    }

    // State machine for multi-step interactions
    const currentState = userStates[chatId];
    if (!currentState) {
      sendWelcomeMessage(chatId);
      return;
    }

    switch (currentState.state) {
      case 'AWAITING_PHONE':
        userStates[chatId].phone = text;
        userStates[chatId].state = 'AWAITING_PASSWORD';
        bot.sendMessage(chatId, '🔑 اکنون رمز عبور خود را وارد کنید:');
        break;

      case 'AWAITING_PASSWORD':
        const phone = userStates[chatId].phone;
        const password = text;
        try {
          const response = await axios.post(`${API_URL}/auth/login`, {
            phone,
            password,
          });
          
          if (response.data.token) {
            userStates[chatId].token = response.data.token;
            userStates[chatId].state = 'LOGGED_IN';
            
            try {
              const decoded = jwt.verify(response.data.token, process.env.JWT_SECRET);
              if (decoded.id) {
                await User.findByIdAndUpdate(decoded.id, { telegramChatId: chatId.toString() });
                await logAction(decoded.id, 'Telegram Bot', 'User Logged In');
              }
            } catch (err) {
              console.error('Error updating user with chatId:', err);
            }

            sendLoggedInMessage(chatId);
          } else {
            delete userStates[chatId];
            bot.sendMessage(chatId, 'ورود ناموفق بود. 😔 شماره یا رمز اشتباه است. لطفاً دوباره تلاش کنید.', welcomeKeyboard);
          }
        } catch (error) {
          delete userStates[chatId];
          bot.sendMessage(chatId, 'خطایی رخ داد. 😔 شماره یا رمز اشتباه است. لطفاً دوباره تلاش کنید.', welcomeKeyboard);
        }
        break;
        
       case 'AWAITING_NOTE_TITLE':
        userStates[chatId].noteTitle = text;
        userStates[chatId].state = 'AWAITING_NOTE_CONTENT';
        bot.sendMessage(chatId, '📝 حالا محتوای یادداشت را وارد کنید:');
        break;

      case 'AWAITING_NOTE_CONTENT':
        const title = userStates[chatId].noteTitle;
        const content = text;
        const userToken = userStates[chatId].token;
        try {
          const decoded = jwt.verify(userToken, process.env.JWT_SECRET);
          await axios.post(
            `${API_URL}/notes`,
            { title, content },
            { headers: { Authorization: `Bearer ${userToken}` } }
          );
          bot.sendMessage(chatId, '✅ یادداشت شما با موفقیت ثبت شد!');
          userStates[chatId].state = 'LOGGED_IN'; // Reset state
          await logAction(decoded.id, 'Telegram Bot', `Created note: "${title}"`);
        } catch (error) {
          bot.sendMessage(chatId, 'خطایی در ثبت یادداشت رخ داد. لطفاً دوباره تلاش کنید. 😥');
          userStates[chatId].state = 'LOGGED_IN';
        }
        break;
        
      default:
         if (userStates[chatId] && userStates[chatId].token) {
            sendLoggedInMessage(chatId);
         } else {
            sendWelcomeMessage(chatId);
         }
    }
  });

  console.log('Telegram Bot has started successfully.');
}