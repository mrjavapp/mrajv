
const User = require('../models/User.js');
const generateToken = require('../utils/generateToken.js');
const logAction = require('../utils/logAction.js');

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
const registerUser = async (req, res) => {
  const { phone, password } = req.body;

  if (!phone || !password) {
    return res.status(400).json({ message: 'لطفا شماره تلفن و رمز عبور را وارد کنید' });
  }

  const userExists = await User.findOne({ phone });

  if (userExists) {
    return res.status(400).json({ message: 'این شماره تلفن قبلا ثبت شده است' });
  }

  const user = await User.create({
    phone,
    password,
  });

  if (user) {
    await logAction(user._id, 'WebApp', 'User Registered');
    res.status(201).json({
      _id: user._id,
      phone: user.phone,
      token: generateToken(user._id),
    });
  } else {
    res.status(400).json({ message: 'اطلاعات کاربر نامعتبر است' });
  }
};

// @desc    Auth user & get token
// @route   POST /api/auth/login
// @access  Public
const loginUser = async (req, res) => {
  const { phone, password } = req.body;
  
  const user = await User.findOne({ phone });

  if (user && (await user.matchPassword(password))) {
    await logAction(user._id, 'WebApp', 'User Logged In');
    res.json({
      _id: user._id,
      phone: user.phone,
      token: generateToken(user._id),
    });
  } else {
    res.status(401).json({ message: 'شماره تلفن یا رمز عبور نامعتبر است' });
  }
};

// @desc    Auth demo user & get token
// @route   POST /api/auth/demo
// @access  Public
const loginDemoUser = async (req, res) => {
  try {
    const demoPhone = process.env.DEMO_USER_PHONE;
    const demoPassword = process.env.DEMO_USER_PASSWORD;

    if (!demoPhone || !demoPassword) {
      console.error('Demo user credentials not set in .env file');
      return res.status(500).json({ message: 'تنظیمات کاربر دمو صحیح نیست' });
    }

    let demoUser = await User.findOne({ phone: demoPhone });

    if (!demoUser) {
      demoUser = await User.create({
        phone: demoPhone,
        password: demoPassword,
      });
      await logAction(demoUser._id, 'WebApp', 'Demo User Created');
    }
    
    await logAction(demoUser._id, 'WebApp', 'Demo User Logged In');
    res.json({
      _id: demoUser._id,
      phone: 'کاربر دمو',
      token: generateToken(demoUser._id),
    });
  } catch (error) {
     res.status(500).json({ message: 'خطای سرور هنگام ورود کاربر دمو' });
  }
};

module.exports = { registerUser, loginUser, loginDemoUser };