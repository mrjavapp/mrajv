
const Log = require('../models/Log.js');

// @desc    Get logged in user's logs
// @route   GET /api/logs
// @access  Private
const getLogs = async (req, res) => {
  // Find logs for the current user, sort by most recent, and limit to 20
  const logs = await Log.find({ user: req.user._id })
    .sort({ createdAt: -1 })
    .limit(20);
    
  res.json(logs);
};

module.exports = { getLogs };