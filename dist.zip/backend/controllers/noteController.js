
const Note = require('../models/Note.js');
const logAction = require('../utils/logAction.js');

// @desc    Get logged in user's notes
// @route   GET /api/notes
// @access  Private
const getNotes = async (req, res) => {
  const notes = await Note.find({ user: req.user._id }).sort({ createdAt: -1 });
  res.json(notes);
};

// @desc    Create a new note
// @route   POST /api/notes
// @access  Private
const createNote = async (req, res) => {
  const { title, content } = req.body;

  if (!title || !content) {
    res.status(400);
    throw new Error('لطفا عنوان و محتوا را وارد کنید');
  } else {
    const note = new Note({
      user: req.user._id,
      title,
      content,
    });

    const createdNote = await note.save();
    await logAction(req.user._id, 'WebApp', `Created note: "${title}"`);
    res.status(201).json(createdNote);
  }
};

// @desc    Update a note
// @route   PUT /api/notes/:id
// @access  Private
const updateNote = async (req, res) => {
  const { title, content } = req.body;
  const note = await Note.findById(req.params.id);

  if (note) {
    // Check if the note belongs to the user
    if (note.user.toString() !== req.user._id.toString()) {
      res.status(401);
      throw new Error('Not authorized');
    }

    note.title = title || note.title;
    note.content = content || note.content;

    const updatedNote = await note.save();
    await logAction(req.user._id, 'WebApp', `Updated note: "${note.title}"`);
    res.json(updatedNote);
  } else {
    res.status(404);
    throw new Error('یادداشت پیدا نشد');
  }
};

// @desc    Delete a note
// @route   DELETE /api/notes/:id
// @access  Private
const deleteNote = async (req, res) => {
  const note = await Note.findById(req.params.id);

  if (note) {
    // Check if the note belongs to the user
    if (note.user.toString() !== req.user._id.toString()) {
      res.status(401);
      throw new Error('Not authorized');
    }

    const noteTitle = note.title;
    await note.deleteOne();
    await logAction(req.user._id, 'WebApp', `Deleted note: "${noteTitle}"`);
    res.json({ message: 'یادداشت حذف شد' });
  } else {
    res.status(404);
    throw new Error('یادداشت پیدا نشد');
  }
};

module.exports = { getNotes, createNote, deleteNote, updateNote };