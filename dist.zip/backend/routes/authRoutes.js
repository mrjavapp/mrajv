const express = require('express');
const router = express.Router();
const { registerUser, loginUser, loginDemoUser } = require('../controllers/authController.js');

router.post('/register', registerUser);
router.post('/login', loginUser);
router.post('/demo', loginDemoUser);

module.exports = router;