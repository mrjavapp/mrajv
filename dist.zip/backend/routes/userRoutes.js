const express = require('express');
const router = express.Router();
const { getUserProfile } = require('../controllers/userController.js');
const { protect } = require('../middleware/authMiddleware.js');

// The 'protect' middleware will be run before getUserProfile
router.route('/profile').get(protect, getUserProfile);

module.exports = router;