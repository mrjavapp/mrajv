
// Force production mode for compatibility with restrictive hosting environments
if (process.env.NODE_ENV !== 'development') {
    process.env.NODE_ENV = 'production';
}

const path = require('path');
const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const noteRoutes = require('./routes/noteRoutes');
const logRoutes = require('./routes/logRoutes');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');
require('./bot'); // Import and start the Telegram bot

dotenv.config();

connectDB();

const app = express();

// CORS configuration to allow requests from the frontend
app.use(cors({
  origin: '*' // In production, you should restrict this to your frontend's domain
}));

app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/notes', noteRoutes); 
app.use('/api/logs', logRoutes);

// --- Serve frontend ---
if (process.env.NODE_ENV === 'production') {
    // Set static folder - it's one level up from `backend` in `dist`
    const distPath = path.resolve(__dirname, '..', 'dist');
    app.use(express.static(distPath));

    // Any route that is not an API route will be redirected to index.html
    app.get('*', (req, res) => {
        if (!req.originalUrl.startsWith('/api/')) {
            res.sendFile(path.resolve(distPath, 'index.html'));
        }
    });
}
// --- End of frontend serving logic ---

// Custom error handling middleware
app.use(notFound);
app.use(errorHandler);


const PORT = process.env.PORT || 3000;

app.listen(PORT, () => console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`));