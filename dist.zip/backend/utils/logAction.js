
const Log = require('../models/Log.js');

const logAction = async (userId, source, action) => {
  try {
    await Log.create({
      user: userId,
      source,
      action,
    });
  } catch (error) {
    console.error(`Failed to create log: ${error.message}`);
  }
};

module.exports = logAction;