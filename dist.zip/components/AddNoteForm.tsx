
import React, { useState, useContext, FormEvent } from 'react';
import { AuthContext } from '../AuthContext';
import { useToast } from '../ToastContext';
import { Note } from '../pages/NotesPage';

interface AddNoteFormProps {
  onNoteAdded: (note: Note) => void;
}

const AddNoteForm: React.FC<AddNoteFormProps> = ({ onNoteAdded }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const auth = useContext(AuthContext);
  const { showToast } = useToast();

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      showToast('error', 'عنوان و محتوا نمی‌توانند خالی باشند.');
      return;
    }
    if (!auth?.user?.token) return;

    setIsSubmitting(true);
    try {
      const response = await fetch('/api/notes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${auth.user.token}`,
        },
        body: JSON.stringify({ title, content }),
      });

      const newNote = await response.json();

      if (!response.ok) {
        throw new Error(newNote.message || 'خطا در ایجاد یادداشت.');
      }
      
      showToast('success', 'یادداشت با موفقیت اضافه شد!');
      onNoteAdded(newNote);
      setTitle('');
      setContent('');
    } catch (err: any) {
      showToast('error', err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <input
          type="text"
          placeholder="عنوان یادداشت"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full px-4 py-2 bg-gray-800 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-[#8700ff] focus:border-[#8700ff]"
          disabled={isSubmitting}
        />
      </div>
      <div>
        <textarea
          placeholder="محتوای یادداشت شما..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="w-full px-4 py-2 bg-gray-800 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-[#8700ff] min-h-[80px]"
          rows={3}
          disabled={isSubmitting}
        />
      </div>
      <div className="text-right">
        <button
          type="submit"
          disabled={isSubmitting}
          className="bg-[#8700ff] hover:bg-purple-700 text-white font-bold py-2 px-5 rounded-md transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-opacity-75 disabled:bg-purple-900 disabled:cursor-not-allowed"
        >
          {isSubmitting ? 'در حال ارسال...' : 'افزودن'}
        </button>
      </div>
    </form>
  );
};

export default AddNoteForm;