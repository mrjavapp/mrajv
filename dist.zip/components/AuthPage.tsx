
import React, { useState, useContext, FormEvent } from 'react';
import { AuthContext } from '../AuthContext';
import { useToast } from '../ToastContext';

type FormMode = 'login' | 'register';

const AuthPage: React.FC = () => {
  const [mode, setMode] = useState<FormMode>('login');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  
  const auth = useContext(AuthContext);
  const { showToast } = useToast();

  if (!auth) return null;

  const { login, register, loginAsDemo } = auth;

  const handleFormSwitch = (newMode: FormMode) => {
    setMode(newMode);
    setPhone('');
    setPassword('');
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!phone || !password) {
        showToast('error', 'لطفا تمام فیلدها را پر کنید.');
        return;
    }

    if (mode === 'login') {
      await login(phone, password);
    } else { // register
      await register(phone, password);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center p-4 font-sans">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-[#8700ff]">زیرو</h1>
          <p className="text-gray-400 mt-2">به پلتفرم ما خوش آمدید</p>
        </div>

        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl shadow-2xl p-8">
          <div className="flex border-b border-gray-700 mb-6">
            <button
              onClick={() => handleFormSwitch('login')}
              className={`w-1/2 pb-3 text-lg font-semibold transition-colors duration-300 focus:outline-none ${mode === 'login' ? 'text-[#8700ff] border-b-2 border-[#8700ff]' : 'text-gray-500 hover:text-gray-300'}`}
              aria-pressed={mode === 'login'}
            >
              ورود
            </button>
            <button
              onClick={() => handleFormSwitch('register')}
              className={`w-1/2 pb-3 text-lg font-semibold transition-colors duration-300 focus:outline-none ${mode === 'register' ? 'text-[#8700ff] border-b-2 border-[#8700ff]' : 'text-gray-500 hover:text-gray-300'}`}
              aria-pressed={mode === 'register'}
            >
              ثبت نام
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-300 mb-2">شماره تلفن</label>
              <div className="relative">
                 <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                    <svg className="w-5 h-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 6.75z" /></svg>
                </div>
                <input
                    id="phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pr-10 pl-4 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-[#8700ff] focus:border-[#8700ff] font-sans"
                    required
                    dir="ltr"
                    autoComplete="tel"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-2">رمز عبور</label>
                <div className="relative">
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                        <svg className="w-5 h-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" /></svg>
                    </div>
                    <input
                        id="password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pr-10 pl-4 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-[#8700ff] focus:border-[#8700ff] font-sans"
                        required
                        dir="ltr"
                        autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                    />
                </div>
            </div>
            
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-[#8700ff] to-purple-600 hover:shadow-lg hover:shadow-purple-500/20 text-white font-bold py-3 px-4 rounded-md transition-all duration-300 ease-in-out transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-purple-500"
            >
              {mode === 'login' ? 'ورود به حساب' : 'ایجاد حساب کاربری'}
            </button>
          </form>

          <div className="mt-6 flex items-center justify-center">
            <div className="w-full border-t border-gray-600"></div>
            <span className="px-2 bg-gray-800 text-gray-400 text-sm flex-shrink-0">یا</span>
            <div className="w-full border-t border-gray-600"></div>
          </div>
          
          <button
            onClick={loginAsDemo}
            className="w-full mt-6 bg-gray-600 hover:bg-gray-700 text-white font-bold py-3 px-4 rounded-md transition-all duration-300 ease-in-out"
            aria-label="ورود به عنوان کاربر دمو"
          >
            ورود کاربر دمو
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;