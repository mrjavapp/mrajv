
import React, { useContext } from 'react';
import { AuthContext } from '../AuthContext';

const Header: React.FC = () => {
  const auth = useContext(AuthContext);

  if (!auth) return null;

  const { logout } = auth;

  return (
    <header className="fixed top-0 right-0 left-0 bg-gray-900/50 backdrop-blur-lg border-b border-gray-700/50 shadow-lg z-30 h-16">
      <div className="container mx-auto flex justify-between items-center h-full px-4">
        <h1 className="text-2xl font-bold text-[#8700ff]">زیرو</h1>
        <button
          onClick={logout}
          aria-label="خروج از حساب کاربری"
          className="bg-[#8700ff] hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-md transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-opacity-75 shadow-md hover:shadow-lg hover:shadow-purple-600/30"
        >
          خروج
        </button>
      </div>
    </header>
  );
};

export default Header;