import React from 'react';
import NotesPage from '../pages/NotesPage';
import SettingsPage from '../pages/SettingsPage';
import { Page } from '../App';

interface MainContentProps {
  currentPage: Page;
}

const MainContent: React.FC<MainContentProps> = ({ currentPage }) => {
  switch (currentPage) {
    case 'notes':
      return <NotesPage />;
    case 'settings':
      return <SettingsPage />;
    default:
      return <NotesPage />;
  }
};

export default MainContent;
