
import React, { useState, useContext } from 'react';
import { Note } from '../pages/NotesPage';
import { AuthContext } from '../AuthContext';
import { useToast } from '../ToastContext';

interface NoteCardProps {
  note: Note;
  onDelete: (noteId: string) => void;
  onUpdate: (updatedNote: Note) => void;
}

const NoteCard: React.FC<NoteCardProps> = ({ note, onDelete, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(note.title);
  const [editedContent, setEditedContent] = useState(note.content);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const auth = useContext(AuthContext);
  const { showToast } = useToast();

  const formattedDate = new Date(note.createdAt).toLocaleDateString('fa-IR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const handleUpdate = async () => {
    if (!editedTitle.trim() || !editedContent.trim()) {
      showToast('error', 'عنوان و محتوا نمی‌توانند خالی باشند.');
      return;
    }
    if (!auth?.user?.token) return;

    setIsSubmitting(true);
    try {
      const response = await fetch(`/api/notes/${note._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${auth.user.token}`,
        },
        body: JSON.stringify({ title: editedTitle, content: editedContent }),
      });
      
      const updatedNote = await response.json();

      if (!response.ok) {
        throw new Error(updatedNote.message || 'خطا در ویرایش یادداشت.');
      }

      onUpdate(updatedNote);
      setIsEditing(false);
      showToast('success', 'یادداشت با موفقیت ویرایش شد.');

    } catch (err: any) {
      showToast('error', err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditedTitle(note.title);
    setEditedContent(note.content);
  };

  if (isEditing) {
    return (
      <div className="bg-gray-800/70 border border-[#8700ff] rounded-lg shadow-lg p-5 flex flex-col justify-between">
        <div>
          <input
            type="text"
            value={editedTitle}
            onChange={(e) => setEditedTitle(e.target.value)}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-[#8700ff] text-xl font-bold mb-2"
            disabled={isSubmitting}
          />
          <textarea
            value={editedContent}
            onChange={(e) => setEditedContent(e.target.value)}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-[#8700ff] min-h-[120px]"
            rows={5}
            disabled={isSubmitting}
          />
        </div>
        <div className="flex justify-end items-center mt-4 pt-3 border-t border-gray-700 space-x-2 space-x-reverse">
          <button onClick={handleCancel} disabled={isSubmitting} className="text-gray-400 hover:text-white transition-colors duration-200 px-3 py-1 rounded-md">لغو</button>
          <button onClick={handleUpdate} disabled={isSubmitting} className="bg-[#8700ff] hover:bg-purple-700 text-white font-bold py-1 px-4 rounded-md transition-colors duration-200 disabled:bg-purple-900">
            {isSubmitting ? '...' : 'ذخیره'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-800/70 border border-gray-700 rounded-lg shadow-lg p-5 flex flex-col justify-between transition-transform transform hover:-translate-y-1">
      <div>
        <h3 className="text-xl font-bold text-[#8700ff] mb-2 break-words">{note.title}</h3>
        <p className="text-gray-300 mb-4 whitespace-pre-wrap break-words">{note.content}</p>
      </div>
      <div className="flex justify-between items-center mt-4 pt-3 border-t border-gray-700">
        <p className="text-xs text-gray-500">{formattedDate}</p>
        <div className="flex items-center space-x-2 space-x-reverse">
            <button onClick={() => setIsEditing(true)} aria-label={`ویرایش یادداشت ${note.title}`} className="text-gray-400 hover:text-blue-400 transition-colors duration-200">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
            </button>
            <button onClick={() => onDelete(note._id)} aria-label={`حذف یادداشت ${note.title}`} className="text-gray-400 hover:text-red-500 transition-colors duration-200">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
            </button>
        </div>
      </div>
    </div>
  );
};

export default NoteCard;