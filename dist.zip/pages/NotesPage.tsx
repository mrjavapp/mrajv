
import React, { useContext, useEffect, useState, useCallback } from 'react';
import { AuthContext } from '../AuthContext';
import AddNoteForm from '../components/AddNoteForm';
import NoteCard from '../components/NoteCard';
import { useToast } from '../ToastContext';

export interface Note {
  _id: string;
  title: string;
  content: string;
  createdAt: string;
}

const NotesPage: React.FC = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const auth = useContext(AuthContext);
  const { showToast } = useToast();

  const fetchNotes = useCallback(async () => {
    if (!auth?.user?.token) return;
    setLoading(true);
    try {
      const response = await fetch('/api/notes', {
        headers: {
          'Authorization': `Bearer ${auth.user.token}`,
        },
      });

      if (!response.ok) {
        if (response.status === 401) auth.logout();
        throw new Error('خطا در دریافت یادداشت‌ها.');
      }

      const data: Note[] = await response.json();
      setNotes(data); // The backend now sends sorted notes
    } catch (err: any) {
      showToast('error', err.message || 'خطا در اتصال به سرور.');
    } finally {
      setLoading(false);
    }
  }, [auth, showToast]);

  useEffect(() => {
    fetchNotes();
  }, [fetchNotes]);

  const handleNoteAdded = (newNote: Note) => {
    setNotes(prevNotes => [newNote, ...prevNotes]);
  };
  
  const handleNoteDeleted = async (noteId: string) => {
    if (!auth?.user?.token) return;
    try {
      const response = await fetch(`/api/notes/${noteId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${auth.user.token}`,
        },
      });

      if (!response.ok) {
        throw new Error('خطا در حذف یادداشت.');
      }
      
      setNotes(prevNotes => prevNotes.filter(note => note._id !== noteId));
      showToast('success', 'یادداشت با موفقیت حذف شد.');

    } catch (err: any) {
      showToast('error', err.message || 'خطای سرور.');
    }
  };

  const handleNoteUpdated = (updatedNote: Note) => {
    setNotes(prevNotes =>
      prevNotes.map(note =>
        note._id === updatedNote._id ? updatedNote : note
      )
    );
  };


  return (
    <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto">
        <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-700 rounded-xl shadow-2xl p-6 mb-8">
            <h1 className="text-2xl font-bold text-[#8700ff] mb-1">سلام، {auth?.user?.phone}</h1>
            <p className="text-gray-400 mb-4">یادداشت جدیدی اضافه کنید.</p>
            <AddNoteForm onNoteAdded={handleNoteAdded} />
        </div>
        
        <div className="border-t border-gray-700 pt-6">
          <h2 className="text-xl font-semibold text-gray-200 mb-4">یادداشت‌های شما</h2>
          {loading ? (
             <p className="text-center text-gray-400">در حال بارگذاری یادداشت‌ها...</p>
          ) : notes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {notes.map(note => (
                <NoteCard key={note._id} note={note} onDelete={handleNoteDeleted} onUpdate={handleNoteUpdated} />
              ))}
            </div>
          ) : (
             <div className="text-center py-10 bg-gray-900/30 rounded-lg">
                <p className="text-gray-400">هنوز یادداشتی ثبت نکرده‌اید.</p>
             </div>
          )}
        </div>
      </div>
    </main>
  );
};

export default NotesPage;