
import React, { useState, useEffect, useContext, useCallback } from 'react';
import { AuthContext } from '../AuthContext';
import { useToast } from '../ToastContext';

interface UserProfile {
    _id: string;
    phone: string;
    hasTelegramConnection: boolean;
}

interface Log {
    _id: string;
    source: string;
    action: string;
    createdAt: string;
}

const SettingsPage: React.FC = () => {
    const [profile, setProfile] = useState<UserProfile | null>(null);
    const [logs, setLogs] = useState<Log[]>([]);
    const [loadingProfile, setLoadingProfile] = useState(true);
    const [loadingLogs, setLoadingLogs] = useState(true);
    
    const auth = useContext(AuthContext);
    const { showToast } = useToast();

    const fetchProfile = useCallback(async () => {
        if (!auth?.user?.token) return;
        setLoadingProfile(true);
        try {
            const response = await fetch('/api/users/profile', {
                headers: {
                    'Authorization': `Bearer ${auth.user.token}`,
                },
            });
            if (!response.ok) {
                throw new Error('خطا در دریافت اطلاعات کاربر.');
            }
            const data = await response.json();
            setProfile(data);
        } catch (err: any) {
            showToast('error', err.message || 'خطای سرور.');
        } finally {
            setLoadingProfile(false);
        }
    }, [auth, showToast]);

    const fetchLogs = useCallback(async () => {
        if (!auth?.user?.token) return;
        setLoadingLogs(true);
        try {
            const response = await fetch('/api/logs', {
                headers: {
                    'Authorization': `Bearer ${auth.user.token}`,
                },
            });
            if (!response.ok) {
                throw new Error('خطا در دریافت تاریخچه فعالیت‌ها.');
            }
            const data = await response.json();
            setLogs(data);
        } catch (err: any) {
            showToast('error', err.message || 'خطای سرور.');
        } finally {
            setLoadingLogs(false);
        }
    }, [auth, showToast]);


    useEffect(() => {
        fetchProfile();
        fetchLogs();
    }, [fetchProfile, fetchLogs]);

    const handleTestNotification = async () => {
        if (!('Notification' in window)) {
            showToast('error', 'مرورگر شما از اعلان‌ها پشتیبانی نمی‌کند.');
            return;
        }

        if (Notification.permission === 'granted') {
            new Notification('اعلان تستی از زیرو', {
                body: 'این یک اعلان موفقیت‌آمیز است!',
                icon: '/vite.svg',
            });
        } else if (Notification.permission !== 'denied') {
            const permission = await Notification.requestPermission();
            if (permission === 'granted') {
                new Notification('اعلان تستی از زیرو', {
                    body: 'این یک اعلان موفقیت‌آمیز است!',
                    icon: '/vite.svg',
                });
            } else {
                showToast('error', 'شما دسترسی به اعلان‌ها را رد کردید.');
            }
        } else {
             showToast('error', 'شما دسترسی به اعلان‌ها را مسدود کرده‌اید.');
        }
    };

    const renderProfileContent = () => {
        if (loadingProfile) {
            return <div className="text-center text-gray-400">...</div>;
        }
        return (
            <div className="flex items-center justify-between">
                <p className="text-gray-300">وضعیت اتصال:</p>
                <div className="flex items-center gap-4">
                    {profile?.hasTelegramConnection ? (
                        <span className="text-green-400 bg-green-900/50 px-3 py-1 rounded-full text-sm font-semibold">متصل</span>
                    ) : (
                        <span className="text-yellow-400 bg-yellow-900/50 px-3 py-1 rounded-full text-sm font-semibold">متصل نیست</span>
                    )}
                    <button onClick={fetchProfile} title="بازخوانی وضعیت" className="text-gray-400 hover:text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 110 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" /></svg>
                    </button>
                </div>
            </div>
        );
    };

    const renderLogsContent = () => {
        if (loadingLogs) {
            return <p className="text-center text-gray-400">در حال بارگذاری لاگ‌ها...</p>;
        }
        if (logs.length === 0) {
            return <p className="text-center text-gray-500">هیچ فعالیتی برای نمایش وجود ندارد.</p>;
        }
        return (
            <ul className="space-y-3 max-h-60 overflow-y-auto pr-2">
                {logs.map(log => (
                    <li key={log._id} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-3">
                           <span className={`text-xs font-semibold px-2 py-1 rounded-full ${log.source === 'WebApp' ? 'bg-blue-900 text-blue-300' : 'bg-green-900 text-green-300'}`}>
                                {log.source === 'WebApp' ? 'وب' : 'تلگرام'}
                           </span>
                           <p className="text-gray-300">{log.action}</p>
                        </div>
                        <p className="text-gray-500 text-xs">
                            {new Date(log.createdAt).toLocaleDateString('fa-IR', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}
                        </p>
                    </li>
                ))}
            </ul>
        );
    }

    return (
        <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
            <div className="max-w-4xl mx-auto">
                 <h1 className="text-3xl font-bold text-gray-100 mb-8">تنظیمات</h1>
                 <div className="space-y-8">
                    {/* Telegram Bot Section */}
                    <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-700 rounded-xl shadow-2xl p-6">
                        <h2 className="text-xl font-bold text-[#8700ff] mb-4 border-b border-gray-700 pb-2">ربات تلگرام</h2>
                        {renderProfileContent()}
                        <p className="text-xs text-gray-500 mt-3">برای اتصال، ربات تلگرام ما را باز کرده و با شماره تلفن خود وارد شوید.</p>
                    </div>

                    {/* Browser Notification Section */}
                    <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-700 rounded-xl shadow-2xl p-6">
                        <h2 className="text-xl font-bold text-[#8700ff] mb-4 border-b border-gray-700 pb-2">اعلان مرورگر</h2>
                        <p className="text-gray-400 mb-4">برای دریافت اعلان‌های مهم، دسترسی لازم را به مرورگر خود بدهید.</p>
                        <button
                            onClick={handleTestNotification}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75"
                        >
                            تست اعلان
                        </button>
                    </div>
                    
                    {/* Activity Log Section */}
                    <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-700 rounded-xl shadow-2xl p-6">
                        <h2 className="text-xl font-bold text-[#8700ff] mb-4 border-b border-gray-700 pb-2">تاریخچه فعالیت‌ها</h2>
                        {renderLogsContent()}
                    </div>
                </div>
            </div>
        </main>
    );
};

export default SettingsPage;